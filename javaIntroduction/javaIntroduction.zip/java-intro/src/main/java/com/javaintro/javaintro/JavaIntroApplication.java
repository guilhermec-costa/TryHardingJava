package com.javaintro.javaintro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaIntroApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaIntroApplication.class, args);
	}

}
