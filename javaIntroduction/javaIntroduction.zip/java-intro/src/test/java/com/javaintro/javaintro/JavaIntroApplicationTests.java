package com.javaintro.javaintro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaIntroApplicationTests {

	@Test
	void contextLoads() {
	}

}
